// Stadium Swap for Madden Team Builder
// Derived from Team Builder Unleashed, Copyright (C) 2026 TeamCrafters (GPL-3.0-or-later).
// Modified for Madden NFL Team Builder. See LICENSE and NOTICE.md.
//
// ISOLATED world: the page-world script cannot read chrome.storage, so it asks us over
// a DOM event and we answer with the armed stadium (or null).
(function () {
  const KEY = 'msStadium';
  window.addEventListener('ms-stadium-request', () => {
    chrome.storage.local.get(KEY, (stored) => {
      const value = stored && stored[KEY] ? stored[KEY] : null;
      window.dispatchEvent(new CustomEvent('ms-stadium-response', { detail: JSON.stringify(value) }));
    });
  });
})();
