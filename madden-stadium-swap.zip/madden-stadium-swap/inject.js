// Stadium Swap for Madden Team Builder
// Derived from Team Builder Unleashed, Copyright (C) 2026 TeamCrafters (GPL-3.0-or-later).
// Modified for Madden NFL Team Builder. See LICENSE and NOTICE.md.
//
// MAIN world. Team Builder saves by PUTting the team payload to a pre-signed S3 URL. If a
// stadium is armed we hold that one request, show a confirmation, and only after you click
// "Apply stadium" do we change two fields in the JSON. On ANY problem the original request
// goes out untouched. With nothing armed, nothing is touched at all.
(function () {
  if (window.__msStadiumSwapInstalled) return;
  window.__msStadiumSwapInstalled = true;

  const nativeFetch = window.fetch.bind(window);
  const XHR = window.XMLHttpRequest;
  const origOpen = XHR.prototype.open;
  const origSend = XHR.prototype.send;

  // Madden's upload host/path are not confirmed yet, so match any S3 PUT and gate on the
  // payload shape instead (must contain teamData.teamInfos and the stadium recipe).
  function isUpload(url, method) {
    try {
      const u = new URL(url, location.href);
      return String(method).toUpperCase() === 'PUT' && /(^|\.)amazonaws\.com$/.test(u.hostname);
    } catch { return false; }
  }

  function getArmedStadium() {
    return new Promise((resolve) => {
      const timer = setTimeout(() => { cleanup(); resolve(null); }, 1500);
      function onResponse(e) {
        cleanup();
        try { resolve(JSON.parse(e.detail)); } catch { resolve(null); }
      }
      function cleanup() {
        clearTimeout(timer);
        window.removeEventListener('ms-stadium-response', onResponse);
      }
      window.addEventListener('ms-stadium-response', onResponse);
      window.dispatchEvent(new CustomEvent('ms-stadium-request'));
    });
  }

  function isObj(v) { return v && typeof v === 'object' && !Array.isArray(v); }

  // Throws with a plain-language reason if the payload doesn't look like what we expect.
  function applyStadium(text, stadium) {
    const id = Number.isInteger(stadium && stadium.stadiumId) ? String(stadium.stadiumId) : '';
    if (!id) throw new Error('The armed stadium has no valid ID.');
    const payload = JSON.parse(text);
    const teamInfos = payload && payload.teamData && payload.teamData.teamInfos;
    if (!isObj(teamInfos)) throw new Error('Could not find teamData.teamInfos in this save.');
    const recipe = payload.teamData.frostbiteData && payload.teamData.frostbiteData.stadiumRecipe;
    if (!isObj(recipe)) throw new Error('Could not find teamData.frostbiteData.stadiumRecipe in this save.');
    const before = teamInfos.STADIUM_ID === undefined ? '(not set)' : String(teamInfos.STADIUM_ID);
    teamInfos.STADIUM_ID = id;
    recipe.assetName = id + '_stadium_recipe';
    return { text: JSON.stringify(payload), before, id };
  }

  function confirmDialog(stadium, info, errorMessage) {
    return new Promise((resolve) => {
      const host = document.createElement('div');
      host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;font:14px system-ui,sans-serif;';
      const box = document.createElement('div');
      box.setAttribute('role', 'dialog');
      box.setAttribute('aria-modal', 'true');
      box.style.cssText = 'background:#fff;color:#111;max-width:440px;margin:16px;padding:20px;border-radius:10px;box-shadow:0 10px 40px rgba(0,0,0,.5);';
      const h = document.createElement('h2');
      h.style.cssText = 'margin:0 0 10px;font-size:18px;';
      h.textContent = errorMessage ? 'Stadium could not be applied' : 'Apply this stadium before saving?';
      const p = document.createElement('p');
      p.style.cssText = 'margin:0 0 16px;line-height:1.4;';
      const name = (stadium && typeof stadium.displayName === 'string' && stadium.displayName.trim()) || 'Selected stadium';
      p.textContent = errorMessage
        ? errorMessage + ' Your save will go through unchanged.'
        : name + ' will change STADIUM_ID from "' + info.before + '" to "' + info.id + '" in this save request.';
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;';
      const mk = (label, primary, value) => {
        const b = document.createElement('button');
        b.textContent = label;
        b.style.cssText = 'padding:8px 14px;border-radius:6px;border:1px solid #888;cursor:pointer;font:inherit;' +
          (primary ? 'background:#0a6;color:#fff;border-color:#0a6;' : 'background:#eee;color:#111;');
        b.addEventListener('click', () => { host.remove(); resolve(value); });
        return b;
      };
      if (errorMessage) {
        row.append(mk('Save unchanged', true, false));
      } else {
        row.append(mk('Save without changes', false, false), mk('Yes, apply stadium', true, true));
      }
      box.append(h, p, row);
      host.append(box);
      (document.body || document.documentElement).append(host);
    });
  }

  // Returns the text to send, or null to send the original.
  async function chooseBody(originalText) {
    if (typeof originalText !== 'string') return null;
    const stadium = await getArmedStadium();
    if (!stadium || !Number.isInteger(stadium.stadiumId)) return null;
    let result = null, error = '';
    try { result = applyStadium(originalText, stadium); }
    catch (err) { error = err.message || String(err); console.warn('[Stadium Swap]', error); }
    const ok = await confirmDialog(stadium, result, error);
    return ok && result ? result.text : null;
  }

  async function bodyToText(body) {
    if (typeof body === 'string') return body;
    if (body instanceof Blob) return body.text();
    if (body instanceof ArrayBuffer) return new TextDecoder().decode(body);
    if (ArrayBuffer.isView(body)) return new TextDecoder().decode(body);
    return null;
  }

  function textToOriginalType(text, original) {
    if (original instanceof Blob) return new Blob([text], { type: original.type });
    if (original instanceof ArrayBuffer) return new TextEncoder().encode(text).buffer;
    if (ArrayBuffer.isView(original)) return new TextEncoder().encode(text);
    return text;
  }

  // Diagnostics: never log the query string, it carries the pre-signed credentials.
  function logSeen(url) {
    try { const u = new URL(url, location.href); console.info('[Stadium Swap] saw upload PUT:', u.hostname + u.pathname); } catch {}
  }

  window.fetch = async function (input, init) {
    const method = (init && init.method) || (input instanceof Request ? input.method : 'GET');
    const url = input instanceof Request ? input.url : String(input);
    if (!isUpload(url, method)) return nativeFetch(input, init);
    try {
      logSeen(url);
      const hasInit = init && Object.prototype.hasOwnProperty.call(init, 'body');
      const original = hasInit ? init.body : (input instanceof Request ? await input.clone().blob() : null);
      const text = original == null ? null : await bodyToText(original);
      const chosen = text === null ? null : await chooseBody(text);
      if (chosen === null) return nativeFetch(input, init);
      return nativeFetch(input, Object.assign({}, init, { body: textToOriginalType(chosen, original) }));
    } catch (err) {
      console.error('[Stadium Swap] save update failed, saving unchanged:', err);
      return nativeFetch(input, init);
    }
  };

  XHR.prototype.open = function (method, url) {
    this.__msInfo = { method: method, url: String(url) };
    return origOpen.apply(this, arguments);
  };

  XHR.prototype.send = function (body) {
    const info = this.__msInfo;
    if (!info || !isUpload(info.url, info.method)) return origSend.call(this, body);
    logSeen(info.url);
    bodyToText(body)
      .then((text) => (text === null ? null : chooseBody(text)))
      .then((chosen) => origSend.call(this, chosen === null ? body : textToOriginalType(chosen, body)))
      .catch((err) => {
        console.error('[Stadium Swap] save update failed, saving unchanged:', err);
        origSend.call(this, body);
      });
  };
})();
